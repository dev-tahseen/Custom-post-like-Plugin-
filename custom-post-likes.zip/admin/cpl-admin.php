<?php
// add the meta key in the database
function cpl_register_meta() {
    register_post_meta('post', '_cpl_like_count', [
        'type' => 'integer',
        'single' => true,
        'default' => 0,
    ]);
}
add_action('init', 'cpl_register_meta');


// Admin settings
function cpl_add_settings_page() {
    add_options_page('Custom Post Likes', 'Post Likes', 'manage_options', 'custom-post-likes', 'cpl_settings_page');
}
add_action('admin_menu', 'cpl_add_settings_page');

// Register settings
function cpl_register_settings() {
    register_setting('cpl_options_group', 'cpl_enable_likes_posts');
    register_setting('cpl_options_group', 'cpl_enable_likes_pages');

}
add_action('admin_init', 'cpl_register_settings');

function cpl_settings_page() {
    ?>
    <div class="wrap">
        <h1>Custom Post Likes Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('cpl_options_group'); ?>
            <?php do_settings_sections('cpl_options_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Enable Likes for Post Types:</th>
                    <td>
                        <label><input type="checkbox" name="cpl_enable_likes_posts" value="1" <?php checked(1, get_option('cpl_enable_likes_posts'), true); ?> /> Posts</label><br />
                        <label><input type="checkbox" name="cpl_enable_likes_pages" value="1" <?php checked(1, get_option('cpl_enable_likes_pages'), true); ?> /> Pages</label><br />
                        <!-- Add more checkboxes for custom post types as needed -->
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}