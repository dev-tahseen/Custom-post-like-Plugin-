<?php
/**
 * Plugin Name: Custom Post Likes
 * Description: A simple plugin to allow users to like posts without logging in.
 * Version: 1.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

if (!defined('CPL_URL')) {
    define('CPL_URL', plugin_dir_url(__FILE__));
}

if (!defined('CPL_BASENAME')) {
    define('CPL_BASENAME', plugin_basename(__FILE__));
}

if (! defined('CPL_PLUGIN_DIR')) {
    define('CPL_PLUGIN_DIR', plugin_dir_path(__FILE__));
}

 // Include admin and front files

include(CPL_PLUGIN_DIR.'admin/cpl-admin.php');

include(CPL_PLUGIN_DIR.'front/cpl-front.php');



// Handle AJAX request to like a post
function cpl_handle_like() {
    check_ajax_referer('cpl_nonce', 'nonce');

    $post_id = intval($_POST['post_id']);
    $like_count = get_post_meta($post_id, '_cpl_like_count', true) ?: 0;

    // Check if user already liked
    if (!isset($_COOKIE['liked_post_' . $post_id])) {
        $like_count++;
        update_post_meta($post_id, '_cpl_like_count', $like_count);
        setcookie('liked_post_' . $post_id, '1', time() + 3600, COOKIEPATH, COOKIE_DOMAIN);
    }

    wp_send_json_success($like_count);
}
add_action('wp_ajax_cpl_like_post', 'cpl_handle_like');
add_action('wp_ajax_nopriv_cpl_like_post', 'cpl_handle_like');


