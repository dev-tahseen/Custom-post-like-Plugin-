jQuery(document).ready(function($) {
    $('.cpl-like-btn').on('click', function() {
        var postId = $(this).parent().data('post-id');

        $.ajax({
            type: 'POST',
            url: cpl_ajax.ajax_url,
            data: {
                action: 'cpl_like_post',
                post_id: postId,
                nonce: cpl_ajax.nonce,
            },
            success: function(response) {
                if (response.success) {
                    $('.cpl-like-count').text(response.data + ' Likes');
                }
            }
        });
    });
});
