<?php
function cpl_enqueue_scripts() {
    wp_enqueue_script('cpl-script', CPL_URL. 'assets/front-script.js', ['jquery'], null, true);
    wp_localize_script('cpl-script', 'cpl_ajax', ['ajax_url' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('cpl_nonce')]);
}
add_action('wp_enqueue_scripts', 'cpl_enqueue_scripts');


// Shortcode to display the like button
function cpl_like_button($atts) {
    global $post;

    $like_count = get_post_meta($post->ID, '_cpl_like_count', true) ?: 0;

    ob_start();
    ?>
    <div class="cpl-like-button" data-post-id="<?php echo esc_attr($post->ID); ?>">
        <button class="cpl-like-btn">Like</button>
        <span class="cpl-like-count"><?php echo esc_html($like_count); ?> Likes</span>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('post_like_button', 'cpl_like_button');
